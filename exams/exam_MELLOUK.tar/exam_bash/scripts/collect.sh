
#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
cd "$ROOT_DIR" || exit 1

LOG_FILE="$ROOT_DIR/logs/collect.logs"
RAW_DIR="$ROOT_DIR/data/raw"
BASE_CSV="$RAW_DIR/sales_data.csv"
OUTPUT_FILE="$RAW_DIR/sales_$(date -u +"%Y%m%d_%H%M").csv"
API_URL="${API_URL:-http://0.0.0.0:5000}"
MODELS=(rtx3060 rtx3070 rtx3080 rtx3090 rx6700)

mkdir -p "$RAW_DIR"
touch "$LOG_FILE"

{
  echo "[$(date -u +"%Y-%m-%dT%H:%M:%SZ")] Début de la collecte"
  echo "API URL: $API_URL"

  if [[ -f "$BASE_CSV" ]]; then
    cp "$BASE_CSV" "$OUTPUT_FILE"
    echo "Fichier source copié : $BASE_CSV vers $OUTPUT_FILE"
  else
    echo "Aucun fichier source $BASE_CSV trouvé, création d'un nouveau fichier"
    printf 'timestamp,model,sales\n' > "$OUTPUT_FILE"
  fi

  timestamp="$(date -u +"%Y-%m-%dT%H:%M:%SZ")"
  for model in "${MODELS[@]}"; do
    echo "Interrogation du modèle : $model"
    response="$(curl -m 10 -sS "$API_URL/$model" 2>&1)" || {
      echo "[$(date -u +"%Y-%m-%dT%H:%M:%SZ")] Erreur API pour $model : $response"
      continue
    }

    if [[ "$response" =~ ^[0-9]+$ ]]; then
      echo "$timestamp,$model,$response" >> "$OUTPUT_FILE"
      echo "[$(date -u +"%Y-%m-%dT%H:%M:%SZ")] $model -> $response"
    else
      echo "[$(date -u +"%Y-%m-%dT%H:%M:%SZ")] Réponse inattendue pour $model : $response"
    fi
  done

  echo "Collecte terminée : $OUTPUT_FILE"
} >> "$LOG_FILE" 2>&1


