#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
cd "$ROOT_DIR" || exit 1

mkdir -p "$ROOT_DIR/logs"
python3 src/train.py >> "$ROOT_DIR/logs/train.logs" 2>&1

