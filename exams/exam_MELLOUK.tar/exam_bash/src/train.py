"""
-------------------------------------------------------------------------------
Ce script exécute l'entraînement d'un modèle de prédiction pour les ventes de
cartes graphiques à partir des données prétraitées.

1. Il commence par rechercher le dernier fichier CSV prétraité dans le dossier
   'data/processed/'.
2. Il charge les données, construit des caractéristiques simples à partir des
   valeurs retardées, puis entraîne un modèle de régression.
3. Le modèle est sauvegardé dans 'model/model.pkl'. Si un modèle existe déjà,
   une copie horodatée est également conservée dans le dossier 'model/'.
4. Les métriques de performance (RMSE, MAE, R²) sont affichées et sauvegardées
   dans les logs.
-------------------------------------------------------------------------------
"""

import sys
from pathlib import Path
from datetime import datetime

import pandas as pd
import joblib
from sklearn.ensemble import RandomForestRegressor
from sklearn.multioutput import MultiOutputRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split

LOG_FILE = Path("logs/train.logs")
MODEL_DIR = Path("model")
PROCESSED_DIR = Path("data/processed")
MODEL_FILE = MODEL_DIR / "model.pkl"

try:
    from xgboost import XGBRegressor
    HAS_XGBOOST = True
except ImportError:
    HAS_XGBOOST = False


def log(message: str, level: str = "INFO") -> None:
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with LOG_FILE.open("a", encoding="utf-8") as log_file:
        log_file.write(f"{timestamp} - {level} - {message}\n")


def get_latest_processed_file() -> Path:
    if not PROCESSED_DIR.exists():
        raise FileNotFoundError(f"Le dossier {PROCESSED_DIR} n'existe pas.")

    processed_files = sorted(PROCESSED_DIR.glob("sales_processed_*.csv"), key=lambda f: f.stat().st_mtime)
    if not processed_files:
        raise FileNotFoundError(f"Aucun fichier 'sales_processed_*.csv' trouvé dans {PROCESSED_DIR}")

    return processed_files[-1]


def load_training_data(file_path: Path) -> pd.DataFrame:
    df = pd.read_csv(file_path)
    if df.empty:
        raise ValueError("Le fichier prétraité est vide.")
    return df


def build_dataset(df: pd.DataFrame):
    if len(df) < 2:
        raise ValueError("Il faut au moins deux lignes pour construire un jeu de données de régression.")

    X = df.shift(1).dropna()
    y = df.loc[X.index].reset_index(drop=True)
    X = X.reset_index(drop=True)

    return X, y


def get_regressor():
    if HAS_XGBOOST:
        base = XGBRegressor(n_estimators=50, max_depth=3, random_state=42, verbosity=0)
    else:
        base = RandomForestRegressor(n_estimators=50, random_state=42)

    return MultiOutputRegressor(base)


def save_model(model):
    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    if MODEL_FILE.exists():
        timestamped_file = MODEL_DIR / f"model_{datetime.now().strftime('%Y%m%d_%H%M')}.pkl"
        joblib.dump(model, timestamped_file)
        log(f"Copie horodatée du modèle créée : {timestamped_file}")

    joblib.dump(model, MODEL_FILE)
    log(f"Modèle sauvé : {MODEL_FILE}")


def evaluate_model(model, X_test, y_test):
    predictions = model.predict(X_test)
    mae = mean_absolute_error(y_test, predictions)
    mse = mean_squared_error(y_test, predictions)
    rmse = mse ** 0.5
    r2 = r2_score(y_test, predictions)

    log(f"Évaluation du modèle - MAE: {mae:.4f}, RMSE: {rmse:.4f}, R2: {r2:.4f}")
    print(f"MAE: {mae:.4f}")
    print(f"RMSE: {rmse:.4f}")
    print(f"R2: {r2:.4f}")


def main() -> int:
    try:
        processed_file = get_latest_processed_file()
        log(f"Chargement du fichier prétraité : {processed_file}")

        df = load_training_data(processed_file)
        X, y = build_dataset(df)

        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        model = get_regressor()
        model.fit(X_train, y_train)

        save_model(model)
        evaluate_model(model, X_test, y_test)

        return 0
    except Exception as exception:
        log(f"Erreur d'entraînement : {exception}", level="ERROR")
        print(f"Erreur d'entraînement : {exception}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
