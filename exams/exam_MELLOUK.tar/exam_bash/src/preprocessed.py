"""
-------------------------------------------------------------------------------
Ce script preprocessed.py récupère les données du dernier fichier CSV créé
dans le dossier 'data/raw/'.

1. Il applique un prétraitement aux données
2. Les résultats du prétraitement sont enregistrés dans un nouveau fichier CSV
   dans le dossier 'data/processed/', avec un nom au format
   'sales_processed_YYYYMMDD_HHMM.csv'.
3. Toutes les étapes du prétraitement sont enregistrées dans le fichier
   'logs/preprocessed.logs' afin de garantir un suivi détaillé du processus.
-------------------------------------------------------------------------------
"""

import pandas as pd
from pathlib import Path
from datetime import datetime
import sys

RAW_DIR = Path("data/raw")
PROCESSED_DIR = Path("data/processed")
LOG_FILE = Path("logs/preprocessed.logs")
EXPECTED_COLUMNS = {"timestamp", "model", "sales"}
KNOWN_MODELS = ["rtx3060", "rtx3070", "rtx3080", "rtx3090", "rx6700"]


def log(message: str) -> None:
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with LOG_FILE.open("a", encoding="utf-8") as log_file:
        log_file.write(f"{timestamp} - {message}\n")


def get_latest_raw_file() -> Path:
    if not RAW_DIR.exists():
        raise FileNotFoundError(f"Le dossier {RAW_DIR} n'existe pas.")

    csv_files = sorted(RAW_DIR.glob("sales_*.csv"), key=lambda f: f.stat().st_mtime)
    if not csv_files:
        raise FileNotFoundError(f"Aucun fichier 'sales_*.csv' trouvé dans {RAW_DIR}")

    return csv_files[-1]


def load_raw_data(file_path: Path) -> pd.DataFrame:
    df = pd.read_csv(file_path)
    if not EXPECTED_COLUMNS.issubset(df.columns):
        raise ValueError(f"Le fichier {file_path} doit contenir les colonnes {EXPECTED_COLUMNS}")

    df = df[list(EXPECTED_COLUMNS)].copy()
    df = df.dropna(subset=["timestamp", "model", "sales"])
    df = df[df["model"].isin(KNOWN_MODELS)]
    df["sales"] = pd.to_numeric(df["sales"], errors="coerce")
    df = df.dropna(subset=["sales"])
    df["sales"] = df["sales"].astype(int)

    if df.empty:
        raise ValueError("Aucun enregistrement valide après nettoyage des données brutes.")

    return df


def preprocess_data(df: pd.DataFrame) -> pd.DataFrame:
    pivot = (
        df.pivot_table(
            index="timestamp",
            columns="model",
            values="sales",
            aggfunc="sum",
            fill_value=0,
        )
        .reset_index()
    )

    for model in KNOWN_MODELS:
        if model not in pivot.columns:
            pivot[model] = 0

    pivot = pivot[KNOWN_MODELS].astype(int)
    return pivot


def build_output_path() -> Path:
    PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M")
    return PROCESSED_DIR / f"sales_processed_{timestamp}.csv"


def main() -> int:
    try:
        raw_file = get_latest_raw_file()
        log(f"Chargement du fichier brut : {raw_file}")

        df = load_raw_data(raw_file)
        log(f"Données brutes chargées : {len(df)} lignes")

        processed_df = preprocess_data(df)
        output_file = build_output_path()
        processed_df.to_csv(output_file, index=False)

        log(f"Fichier prétraité sauvegardé : {output_file}")
        print(f"Prétraitement réussi : {output_file}")
        return 0
    except Exception as exception:
        log(f"Erreur de prétraitement : {exception}")
        print(f"Erreur de prétraitement : {exception}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
