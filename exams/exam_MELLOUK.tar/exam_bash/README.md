### Comment tester le projet :
1. **Se placer dans le dossier du projet :**
```bash
cd /home/ubuntu/exam_MELLOUK/exam_bash
```
2. **Activer l’environnement virtuel :**
```bash
source bash_exam/bin/activate
```
3. **Lancer les tests :**
```bash
make tests
```


### Résultat des tests : 3/3 reussis
pytest tests/test_collect.py
================================================================ test session starts ================================================================
platform linux -- Python 3.12.3, pytest-9.0.3, pluggy-1.6.0
rootdir: /home/ubuntu/exam_MELLOUK/exam_bash
configfile: pyproject.toml
collected 1 item                                                                                                                                    

tests/test_collect.py .                                                                                                                       [100%]

================================================================= 1 passed in 0.49s =================================================================
pytest tests/test_preprocessed.py
================================================================ test session starts ================================================================
platform linux -- Python 3.12.3, pytest-9.0.3, pluggy-1.6.0
rootdir: /home/ubuntu/exam_MELLOUK/exam_bash
configfile: pyproject.toml
collected 1 item                                                                                                                                    

tests/test_preprocessed.py .                                                                                                                  [100%]

================================================================= 1 passed in 0.51s =================================================================
pytest tests/test_model.py
================================================================ test session starts ================================================================
platform linux -- Python 3.12.3, pytest-9.0.3, pluggy-1.6.0
rootdir: /home/ubuntu/exam_MELLOUK/exam_bash
configfile: pyproject.toml
collected 1 item                                                                                                                                    

tests/test_model.py .                                                                                                                         [100%]

================================================================= 1 passed in 0.01s =================================================================